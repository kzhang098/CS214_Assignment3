package chess.model;

import android.support.annotation.DrawableRes;

import com.example.pwarner.myapplication.R;

import java.util.ArrayList;

import chess.service.Piece;

/**
 *
 * @author Kenneth Zhang and Paul Warner
 *
 */

public class Bishop extends Piece{

    public Bishop(String color) {
        this.color = color;
    }

    @Override
    public int getIcon() {
        return getColor().equals("Black") ? R.drawable.bb : R.drawable.wb;
    }

    @Override
    public ArrayList<int[]> allMoves(int[] origin) {
        ArrayList<int[]> moves = new ArrayList<int[]>();
        moves.addAll(walkDirection(origin, 1, 1));
        moves.addAll(walkDirection(origin, 1, -1));
        moves.addAll(walkDirection(origin, -1, 1));
        moves.addAll(walkDirection(origin, -1, -1));

        return moves;
    }

    public boolean isHasMoved() {
        return hasMoved;
    }

    public void setHasMoved(boolean hasMoved) {
        this.hasMoved = hasMoved;
    }

    public String getColor() {
        return color;
    }

    public String toString() {
        if (color.equals("Black")){
            return "bB ";
        } else {
            return "wB ";
        }
    }

}
