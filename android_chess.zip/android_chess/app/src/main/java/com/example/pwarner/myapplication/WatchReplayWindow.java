package com.example.pwarner.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import chess.service.Chessboard;

/**
 * Created by pwarner on 5/1/16.
 */
public class WatchReplayWindow extends ChessView {

    File gameFile;
    Scanner gameScanner;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.replaychess);
        setBoardLayout((LinearLayout)findViewById(R.id.boardview));
        setTurn((TextView)findViewById(R.id.currentTurn));
        setCheck((TextView)findViewById(R.id.check));
        Bundle b = getIntent().getExtras();
        String fp = b.getString("fp");
        System.out.println(fp);
        gameFile = new File(fp);
        try {
            gameScanner = new Scanner(gameFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1); // will never happen
        }
        setup();
    }

    public void nextMove(View v) {
        if (!inGame)
            return;
        int[][] m = getNextMove();
        move(m);
    }

    @Override
    protected void clicked(View v) {}

    @Override
    protected void undoLast(View v) {}

    @Override
    protected void resign(View v) {}

    @Override
    protected void endGame() {}


    private int[][] getNextMove() {
        if (!inGame)
            return null;
        int[][] m = new int[3][2];
        m[0][0] = gameScanner.nextInt();
        m[0][1] = gameScanner.nextInt();
        m[1][0] = gameScanner.nextInt();
        m[1][1] = gameScanner.nextInt();
        if (Chessboard.isPromotion(Chessboard.getTurn(), m[0], m[1])) {
            m[2][0] = gameScanner.nextInt();
        }

        return m;
    }
}
