package com.example.pwarner.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

import chess.service.Chessboard;
import chess.service.Piece;

public class PlayWindow extends ChessView {

    private ImageButton src;
    private ImageButton dst;
    private CheckBox drawCheckBox;
    private boolean recording;

    StringBuilder game;
    private String fileName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.playchess);
        recording = getIntent().getExtras().getBoolean("recorded");
        drawCheckBox = (CheckBox)findViewById(R.id.drawcheck);
        setBoardLayout((LinearLayout)findViewById(R.id.boardview));
        setTurn((TextView)findViewById(R.id.currentTurn));
        setCheck((TextView)findViewById(R.id.check));
        game = new StringBuilder();
        game.append("\n");
        setup();
    }

    int[][] move;

    public void clicked(View v) {
        if (!inGame)
            return;
        ImageButton button = (ImageButton)v;
        if (src == null) {
            Piece p = Chessboard.getPieceAt(getCoordinates(button));
            if (p == null || !p.getColor().equals(Chessboard.getTurn()))
                return;
            src = button;
            button.setColorFilter(Color.argb(155, 185, 185, 185));
        } else if (src == button) {
            button.setColorFilter(null);
            src = null;
        } else {
            dst = button;
            int[][] m = new int[3][2];
            m[0] = getCoordinates(src);
            m[1] = getCoordinates(dst);
            m[2][0] = 0;
            if(Chessboard.isPromotion(Chessboard.getTurn(), m[0], m[1])) {
                move = m;
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Select the piece you'd like to promote to");
                builder.setItems(new CharSequence[]
                                {"Queen", "Bishop", "Knight", "Rook"},
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                promo(which, move);
                            }
                        });
                builder.create().show();
            } else {
                doMove(m);
            }


        }
    }

    //added this method;

    protected void promo(int i, int[][] m) {
        m[2][0] = i;
        doMove(m);
    }

    private void doMove(int[][] m) {
        if (move(m)) {
            turnUndone = false;
            isFirst = false;
            addMove(getCoordinates(src), getCoordinates(dst), m[2][0]);
            src.setColorFilter(null);
            dst.setColorFilter(null);
            src = null;
            dst = null;
            if (drawCheckBox.isChecked()) {
                draw();
            }
        }
    }

    public void randomMove(View v) {
        if (!inGame)
            return;
       int[][] m = Chessboard.randomMove();


        // move can't be null

        move(m);
        addMove(m[0], m[1], m[2][0]);
        turnUndone = false;
        isFirst = false;
        if (src != null) {
            src.setColorFilter(null);
            src = null;
        }
        if (dst != null) {
            dst.setColorFilter(null);
            dst = null;
        }
    }

    public void endGame() {
        inGame = false;
        if (!recording)
            return;
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Save your game?");

        final EditText input = new EditText(this);

        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {}
        });

        final AlertDialog d = builder.create();

        d.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(DialogInterface dialog) {
                Button b = d.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String regex = "^[a-zA-Z0-9 ]+$";
                        fileName = input.getText().toString();
                        if(!fileName.matches(regex)) {
                            Toast t = Toast.makeText(getApplicationContext(), "Enter a name consisting only of alphanumeric characters", Toast.LENGTH_SHORT);
                            t.show();
                            return;
                        }
                        File sDir = new File(getFilesDir(), "savedGames");
                        if (new File(sDir, fileName).exists()) {
                            Toast t = Toast.makeText(getApplicationContext(), "There is already a save with that name!", Toast.LENGTH_SHORT);
                            t.show();
                            return;
                        } else {
                            try {
                                FileOutputStream outputStream = new FileOutputStream(new File(sDir, fileName));
                                outputStream.write(game.toString().getBytes());
                                outputStream.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                                return;
                            }
                            Intent intent = new Intent(getBaseContext(), ChessWindow.class);
                            startActivity(intent);
                        }
                    }
                });
            }
        });
        d.show();
    }

    // cannot undo move on first turn of directly after someone has undone a turn
    private boolean isFirst = true;
    private boolean turnUndone = false;

    public void undoLast(View v) { //ADDED THIS
        if (!inGame || isFirst || turnUndone) // Consider adding error message here
            return;

        Chessboard.undoChessTurn();
        updateDisplay();
        int last, prev = game.length() - 1;
        while ((last = game.lastIndexOf("\n")) == prev) {
            prev = last-1;
        }
        game.delete(last, game.length());
        turnUndone = true;
    }

    public void draw() {
        Chessboard.offerDraw();
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setMessage("A draw has been offered. Would you accept?");
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        manDisplay("D");
                        endGame();
                    }
                });
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.show();
    }

    public void resign(View v) {
        if (!inGame)
            return;
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setMessage("Are you sure you would like to resign?");
        dialog.setButton(AlertDialog.BUTTON_POSITIVE, "YES",

                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        manDisplay("R");
                        endGame();
                    }
                });
        dialog.setButton(AlertDialog.BUTTON_NEGATIVE, "NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.show();
    }

    private void addMove(int[] src, int[] dst, int i) {
        game.append(String.format(Locale.getDefault(), "\n%d %d %d %d", src[0], src[1], dst[0], dst[1]));
        if (Chessboard.isPromotion(Chessboard.getTurn(), src, dst)) {
            game.append(String.format(Locale.getDefault(), " %d", i));
        } else {
            game.append(String.format(Locale.getDefault(), ""));
        }
    }

}
