package com.example.pwarner.myapplication;

/**
 * Created by pwarner on 4/22/16.
 */

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import chess.service.Chessboard;
import chess.service.Piece;

public abstract class ChessView extends AppCompatActivity {

    private LinearLayout boardLayout;
    private TextView turn;
    private TextView check;

    protected boolean inGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void setBoardLayout(LinearLayout boardLayout) {
        this.boardLayout = boardLayout;
    }

    public void setTurn(TextView turn) {
        this.turn = turn;
    }

    public void setCheck(TextView check) { this.check = check; }

    protected void printBoard() {
        int[] vec = new int[2];
        Piece p;
        ImageButton button;
        LinearLayout row;
        for (int i = 0; i < 8; ++i) {
            vec[0] = i;
            row = (LinearLayout)boardLayout.getChildAt(i);
            for (int j = 0; j < 8; ++j) {
                vec[1] = j;
                button = (ImageButton)row.getChildAt(j);
                p = Chessboard.getPieceAt(vec);
                int res = p == null ? isShaded(vec) : p.getIcon();
                button.setImageResource(res);
            }
        }
    }

    protected void setup() {
        Chessboard.setup();
        inGame = true;
        updateDisplay();
    }

    protected void updateDisplay() {
        printBoard();
        String currentTurn = Chessboard.getTurn();
        turn.setText(currentTurn);
        if (Chessboard.inStalemate(currentTurn)) {
            if (Chessboard.inCheck(currentTurn)) {
                check.setText("Checkmate");
            } else {
                check.setText("Stalemate");
            }

        } else if (Chessboard.inCheck(currentTurn)) {
            check.setText("check");
        } else {
            check.setText("");
        }
    }

    protected boolean move(int[][] m) {
        final String msg = Chessboard.doTurn(m);

        updateDisplay();
        if (msg != null) {

            AlertDialog dialog = new AlertDialog.Builder(ChessView.this).create();
            dialog.setMessage(msg);
            dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    if (msg.startsWith("Checkmate") || msg.startsWith("Stalemate")) {
                        inGame = false;
                        endGame();
                    }
                }
            });
            dialog.show();
            if (msg.startsWith("Checkmate") || msg.startsWith("Stalemate")) { // TODO try to mess around with some of this stuff here
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    protected abstract void clicked(View v);

    protected int[] getCoordinates(ImageButton v) {
        int[] vec = new int[2];
        vec[0] = boardLayout.indexOfChild((ViewGroup)v.getParent());
        vec[1] = ((ViewGroup) v.getParent()).indexOfChild(v);
        return Chessboard.isValid(vec) ? vec : null;
    }

    /**
     * Given a particular set of two variables, return the correct drawable id
     * referencing the correct color that square should be.
     * @param vec the coordinates of the square
     * @return The drawable id represented by that square
     */
    private @DrawableRes int isShaded(int[] vec) {
        if ((vec[0] % 2 == 0 && vec[1] % 2 == 0) || (vec[0] % 2 != 0 && vec[1] % 2 != 0)) { // black
            return R.drawable.black; // black squares
        } else {
            return R.drawable.white; // white squares
        }
    }

    protected void manDisplay(String key) {

        if(key.equals("CM")) {

            if (Chessboard.getTurn().equals("White")) {
                turn.setText("White Wins");
            } else if (Chessboard.getTurn().equals("Black")) {
                turn.setText("Black Wins");
            }
        } else if(key.equals("D")) {
            turn.setText("DRAW!");
        } else if(key.equals("S")) {
            turn.setText("STALEMATE!");
        } else if(key.equals("R")) {
            check.setText("Resigned");
        }
    }
    protected abstract void undoLast(View v);
    protected abstract void resign(View v);
    protected abstract void endGame();

}
