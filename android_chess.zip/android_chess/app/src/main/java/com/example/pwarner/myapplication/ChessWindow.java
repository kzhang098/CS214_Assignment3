package com.example.pwarner.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.io.File;

public class ChessWindow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chess_window);
        setupSaves();
    }

    private void setupSaves() {
        File fileDir = getFilesDir();
        File sDir;
        sDir = new File(fileDir, "savedGames");
        if(!sDir.exists()) {
            sDir.mkdir();
        } else {
//            System.out.println("deleting files...");
//            File[] files = sDir.listFiles();
//            for (File f : files) {
//                f.delete();
//            }
        }
    }

    void playClicked(View v) {
        Intent i = new Intent(ChessWindow.this, PlayWindow.class);
        i.putExtra("recorded", false);

        startActivity(i);
    }

    void recordClicked(View v) {
        Intent i = new Intent(ChessWindow.this, PlayWindow.class);
        i.putExtra("recorded", true);

        startActivity(i);
    }

    void rewatchClicked(View v) {
        startActivity(new Intent(ChessWindow.this,ReplayWindow.class));
    }
}
