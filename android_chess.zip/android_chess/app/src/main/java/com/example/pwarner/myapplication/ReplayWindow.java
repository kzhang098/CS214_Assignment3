package com.example.pwarner.myapplication;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

/**
 * Created by Wise_Hermit on 4/22/2016.
 */
public class ReplayWindow extends ListActivity {

    ArrayList<String> listView = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rewatch_list);
        listView = getFileName("/src/main/res/savedGames");
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listView);
        setListAdapter(adapter);
    }

    public ArrayList<String> getFileName(String directory) {
        ArrayList<String> fileNames= new ArrayList<String>();
        File f = new File(getFilesDir(), "savedGames");

        File[] files = f.listFiles();

        if(files.length == 0) {
            AlertDialog d = new AlertDialog.Builder(this).create();
            d.setMessage("You have no games saved!");
            d.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(getBaseContext(), ChessWindow.class);
                            startActivity(intent);
                        }
                    });
            d.show();

        } else {
            for(int i = 0; i < files.length ; i++) {
                fileNames.add(i,files[i].getName());
            }
        }

        return fileNames;
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        File f = new File(new File(getFilesDir(), "savedGames"), ((TextView)l.getChildAt(position)).getText().toString());
        Intent i = new Intent(this, WatchReplayWindow.class);
        i.putExtra("fp", f.getAbsolutePath());
        startActivity(i);
    }

    public void dateSort(View v) {

        File f = new File(getFilesDir(), "savedGames");
        File [] files = f.listFiles();

        listView.clear();

        Arrays.sort(files, new Comparator()
        {
            public int compare(Object o1, Object o2) {

                if (((File)o1).lastModified() > ((File)o2).lastModified()) {
                    return -1;
                } else if (((File)o1).lastModified() < ((File)o2).lastModified()) {
                    return +1;
                } else {
                    return 0;
                }
            }

        });

        if(files.length != 0) {
            for(int i = 0; i < files.length ; i++) {
                listView.add(i,files[i].getName());
            }
        }

        adapter.notifyDataSetChanged();
    }

    public void nameSort(View v) {
        Collections.sort(listView, new Comparator<String>() {
            @Override
            public int compare(String s, String t1) {
                return s.compareToIgnoreCase(t1);
            }
        });
        adapter.notifyDataSetChanged();
    }

}
