#include "libnetfiles.h"


//First argument will be the hostname (this is resolved using the gethostbyname() function)
//Port number will be the second argument. Make sure you convert this char string to integer using atoi() 
int main(int argc, char ** argv) {
	//Get standard input. The default number of bytes to read is 256.
	
	int i;
	netserverinit(argv[1], 2);
	
	char * test = malloc(50);
	int fd = netopen("./Hints.txt", 2);
	
	while(1) {
	
	}
	
	return 0; 
}
